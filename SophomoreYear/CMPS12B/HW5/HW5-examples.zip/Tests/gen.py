for i in range(3,40):
    for j in range(0,10):
        print(str(i)+' '+str(j))
